import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const SleepyApp());

class SleepyApp extends StatelessWidget {
  const SleepyApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Sleepy',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF080D1B),
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF9AAEFF),
        brightness: Brightness.dark,
      ),
      useMaterial3: true,
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Timer? _timer;
  int _seconds = 0;
  String _sound = 'Rain';
  bool _playing = false;
  bool _premium = false;

  final sounds = const [
    ('Rain', 'Soft rain ambience', Icons.water_drop_outlined),
    ('Ocean', 'Calm ocean waves', Icons.waves),
    ('Forest', 'Night forest ambience', Icons.forest_outlined),
    ('White Noise', 'Gentle steady noise', Icons.graphic_eq),
  ];

  void _togglePlay() {
    setState(() => _playing = !_playing);
    if (_playing && _seconds == 0) _startTimer(30);
  }

  void _startTimer(int minutes) {
    _timer?.cancel();
    setState(() => _seconds = minutes * 60);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_seconds <= 1) {
        t.cancel();
        setState(() { _seconds = 0; _playing = false; });
      } else {
        setState(() => _seconds--);
      }
    });
  }

  String _time() {
    final m = _seconds ~/ 60, s = _seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override void dispose() { _timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sleepy 🌙',
          style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 6, 18, 32),
        children: [
          const Text('Good night',
            style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          Text('Relax. Breathe. Sleep.',
            style: TextStyle(color: Colors.white.withOpacity(.62))),
          const SizedBox(height: 20),

          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              gradient: const LinearGradient(
                colors: [Color(0xFF29366E), Color(0xFF101A39)],
              ),
            ),
            child: Column(children: [
              const Text('Tonight’s session',
                style: TextStyle(fontSize: 17)),
              const SizedBox(height: 8),
              Text(_time(),
                style: const TextStyle(
                  fontSize: 44, fontWeight: FontWeight.w700)),
              const SizedBox(height: 5),
              Text(_sound, style: const TextStyle(fontSize: 15)),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _togglePlay,
                icon: Icon(_playing ? Icons.pause : Icons.play_arrow),
                label: Text(_playing ? 'Pause' : 'Start sleep'),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [15, 30, 60].map((m) =>
                  OutlinedButton(
                    onPressed: () => _startTimer(m),
                    child: Text('$m min'),
                  )).toList(),
              ),
            ]),
          ),

          const SizedBox(height: 25),
          const Text('Sleep sounds',
            style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),

          ...sounds.map((s) => Card(
            color: const Color(0xFF12192B),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: const Color(0xFF26345F),
                child: Icon(s.$3),
              ),
              title: Text(s.$1),
              subtitle: Text(s.$2),
              trailing: _sound == s.$1
                ? const Icon(Icons.check_circle)
                : const Icon(Icons.chevron_right),
              onTap: () => setState(() => _sound = s.$1),
            ),
          )),

          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.white12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('⭐ Sleepy Premium',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('More sounds, sleep stories and relaxing themes.'),
                const SizedBox(height: 14),
                Text(_premium ? 'Premium active' : '₹49 / month',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                const SizedBox(height: 10),
                FilledButton(
                  onPressed: () => setState(() => _premium = true),
                  child: Text(_premium ? 'Premium active ✓' : 'Try Premium'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
